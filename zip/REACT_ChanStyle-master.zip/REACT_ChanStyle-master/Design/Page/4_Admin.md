# Admin Page 

<img src="../img/Admin.png" width="80%" />