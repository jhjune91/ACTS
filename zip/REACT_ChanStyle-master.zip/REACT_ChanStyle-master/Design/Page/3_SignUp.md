# SignUp Page 

<img src="../img/SignUp.png" width="80%" />