# ProductView Page 

<img src="../img/ProductView.png" width="80%" />