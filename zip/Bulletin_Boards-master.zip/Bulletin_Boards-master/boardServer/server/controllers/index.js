
const board = require('./board');

module.exports = {
  board
};
