import React,{Component} from 'react';
import IndexRoute from './Routes';

class IndexComponent extends Component
{
    render()
    {
            return(<IndexRoute/>)
    }
} 

export default IndexComponent;