import React from "react";
import Routes from "./Routes";
import '../src/Routes/Components/assets/css/index';
export default () => <Routes />;
